-- AlterTable
ALTER TABLE "Contract" ADD COLUMN     "chatChannelUrl" TEXT;
