import bodyParser from "body-parser";
export const rawBody = bodyParser.raw({ type: "*/*" });
